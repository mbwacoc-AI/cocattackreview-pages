# CocAttackReview GitHub Pages

This folder contains a small public website for the CocAttackReview YouTube API compliance review.

## Before publishing

Replace every occurrence of:

    REPLACE_WITH_CONTACT_EMAIL

with an email address you are comfortable publishing publicly.

## Recommended repository layout

Copy the `docs` folder into the root of your GitHub repository:

    your-repository/
      docs/
        index.html
        privacy.html
        terms.html

## Enable GitHub Pages

In GitHub:

1. Open the repository.
2. Go to **Settings** -> **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the default branch (usually `main`) and the `/docs` folder.
5. Save and wait for the public URL to appear.

Typical URLs will look like:

    https://<github-user>.github.io/<repository>/
    https://<github-user>.github.io/<repository>/privacy.html
    https://<github-user>.github.io/<repository>/terms.html

Use the first as the main website and the second as the privacy-policy URL in the YouTube API audit form.

## Notes

- The site contains no JavaScript, analytics, advertising, or intentional tracking.
- Keep the text accurate if the tool's behavior changes.
- This draft is written for a single-user, local desktop tool.
